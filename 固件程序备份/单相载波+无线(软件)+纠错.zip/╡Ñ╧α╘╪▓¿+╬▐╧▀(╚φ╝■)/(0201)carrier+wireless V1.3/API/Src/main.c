/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "main_process.h"
#include "stm32f030_peripheral.h"
#include "wireless_app.h"

IWDG_HandleTypeDef      IwdgHandle;
__IO uint32_t           time_tick;
WLS WIRELESS_DATA;      //�������߽ṹ�� 
volatile uint8_t WIRELESS_LED_FLAG;    //���߽���״ָ̬ʾ��־

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Config(void);
static void Error_Handler(void);
static void BoardEvalConfig(void);
static void IWDT_Config(void);
void SysTickCallback (void);
/**
  * @brief  Main program
  * @param  None
  * @retval None
  */
int main(void)
{
  HAL_Init();
  /* Configure the system clock to have a system clock = 48 Mhz */
  SystemClock_Config();
  BSP_LED_Init(LED1);
  BSP_LED_Init(LED2);
  BSP_LED_Init(LED3);
  BSP_LED_Init(LED4);
  if(Wireless_Init() == Wireless_NoError) //Initial Wireless��
  {
    GPIOA->BSRR = 1<<5;   //RLED Light On
    HAL_Delay(100);
    GPIOA->BRR = 1<<5;      //RLED Close
    HAL_Delay(100);
     GPIOA->BSRR = 1<<5;   //RLED Light On
    HAL_Delay(100);
    GPIOA->BRR = 1<<5;      //RLED Close
    HAL_Delay(500);
  }
  
  Si4438_Receive_Start(WIRELESS_CHANNEL);   //Start Receive 
  
  /*** ���߽��ղ���***
  while(1)
  {
    if(WIRELESS_STATUS == Wireless_RX_Finish)         //Send Finish
    {
      WIRELESS_STATUS = Wireless_Free;
      GPIOA->ODR ^= 1<<1;       //����
      Si4438_Receive_Start(WIRELESS_CHANNEL);         //Start Receive
    }
    
    else if(WIRELESS_STATUS == Wireless_RX_Failure)   //���մ���
    { 
      WIRELESS_STATUS = Wireless_Free;
      Si4438_Receive_Start(WIRELESS_CHANNEL);
    }
  }
  
  *****/
  /*Board Init*/
  BoardEvalConfig();
  
#ifdef USE_WDT
  IWDT_Config();
#endif
#if 0
  //HAL_NVIC_SystemReset();
  uint8_t i;
  for(i=0;i<0xff;i++)
    gDownTxBuffer[i] = i; 
  FLASHWrite(0,(uint32_t *)gDownTxBuffer,sizeof(gDownTxBuffer)/4);
  FLASHRead(0,(uint32_t *)gDownRxProcess,sizeof(gDownRxProcess)/4);
#endif

  main_process();
}

static void SystemClock_Config(void)
{
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
#if 1
  RCC_OscInitTypeDef RCC_OscInitStruct;

  /* Enable HSE Oscillator and Activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct)!= HAL_OK)
  {
    Error_Handler();
  }
#else
  uint32_t tickstart = 0;
/* When the HSE is used as system clock or clock source for PLL in these cases it is not allowed to be disabled */
  if((__HAL_RCC_GET_SYSCLK_SOURCE() == RCC_SYSCLKSOURCE_STATUS_HSE) ||
     ((__HAL_RCC_GET_SYSCLK_SOURCE() == RCC_SYSCLKSOURCE_STATUS_PLLCLK) && (__HAL_RCC_GET_PLL_OSCSOURCE() == RCC_PLLSOURCE_HSE)))
  {
    if((__HAL_RCC_GET_FLAG(RCC_FLAG_HSERDY) != RESET))
    {
      return ;
    }
  }
  else
  {
    /* Reset HSEON and HSEBYP bits before configuring the HSE --------------*/
    __HAL_RCC_HSE_CONFIG(RCC_HSE_OFF);
    
    /* Get timeout */
    tickstart = HAL_GetTick();
    
    /* Wait till HSE is ready */
    while(__HAL_RCC_GET_FLAG(RCC_FLAG_HSERDY) != RESET)
    {
      if((HAL_GetTick() - tickstart) > HSE_TIMEOUT_VALUE)
      {
        return ;
      }
    }

    /* Set the new HSE configuration ---------------------------------------*/
    __HAL_RCC_HSE_CONFIG(RCC_HSE_ON);

    /* Get timeout */
    tickstart = HAL_GetTick();
  
    /* Wait till HSE is ready */  
    while(__HAL_RCC_GET_FLAG(RCC_FLAG_HSERDY) == RESET)
    {
      if((HAL_GetTick() - tickstart) > HSE_TIMEOUT_VALUE)
      {
        return;
      }
    }
  }
 /*-------------------------------- PLL Configuration -----------------------*/
 /* Check if the PLL is used as system clock or not */
  if(__HAL_RCC_GET_SYSCLK_SOURCE() != RCC_SYSCLKSOURCE_STATUS_PLLCLK)
  {
      /* Disable the main PLL. */
      __HAL_RCC_PLL_DISABLE();

      /* Get timeout */
      tickstart = HAL_GetTick();
    
      /* Wait till PLL is ready */  
      while(__HAL_RCC_GET_FLAG(RCC_FLAG_PLLRDY) != RESET)
      {
        if((HAL_GetTick() - tickstart) > PLL_TIMEOUT_VALUE)
        {
          return;
        }
      }

      /* Configure the main PLL clock source, predivider and multiplication factor. */
      __HAL_RCC_PLL_CONFIG(RCC_PLLSOURCE_HSE,
                           RCC_PREDIV_DIV1,
                           RCC_PLL_MUL6);
      
      /* Enable the main PLL. */
      __HAL_RCC_PLL_ENABLE();

      /* Get timeout */
      tickstart = HAL_GetTick();
    
      /* Wait till PLL is ready */  
      while(__HAL_RCC_GET_FLAG(RCC_FLAG_PLLRDY) == RESET)
      {
        if((HAL_GetTick() - tickstart) > PLL_TIMEOUT_VALUE)
        {
          return ;
        }
      }
  }

#endif
  /* Select PLL as system clock source and configure the HCLK and PCLK1 clocks dividers */
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1);
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1)!= HAL_OK)
  {
    Error_Handler();
  }
}

static void BoardEvalConfig(void)
{
  //BSP_LED_Init(LED1);
  //BSP_LED_Init(LED2);
  //BSP_LED_Init(LED3);
  //BSP_LED_Init(LED4);
  
  Init_lowlevel_para();
  
  USARTx_Init();
 // Crc_Init();
  SigInConfig();
  EXTI4_15_IRQHandler_Config(); 
  InitPWMTime();
  //DisablePWMOut();
  InitFskOutATime();
  DisableFskOutATime();
  InitFskOutBTime();
  DisableFskOutBTime();
  InitFskOutCTime();
  DisableFskOutCTime();
  /* 38KHz */
  //Init38KhzOutTime();
  InitSampeTime();
  DisableSampeTime();
  InitPhaseTime();
#ifdef USE_ADC  
  SigInADCIOCofnig();
#endif
}

void SysTickCallback (void)
{ 
  static uint8_t LEDR_blink_cnt;      //���ߵ�������
  if((HAL_GetTick()%10) == 0)
  {
    time_tick ++;
/************** ���ߵ����ж� *******************/
    if(WIRELESS_LED_FLAG)
    {
      if(WIRELESS_LED_FLAG == 1)
      {
        if((LEDR_blink_cnt & 0x03) == 0)
        {
          GPIOA->ODR ^= 1<<1;       //����
        }
        if(++LEDR_blink_cnt > 15)
        {
          LEDR_blink_cnt = 0;
          GPIOA->BRR = 1<<1;      //��Ϩ
          WIRELESS_LED_FLAG = 0;  //���־
        }
      }
      else if(WIRELESS_LED_FLAG == 2)
      {
        WIRELESS_LED_FLAG = 0;  //���־
        LEDR_blink_cnt = 0;     //������0
      }
    }
/****************** END ************************/
    if((HAL_GetTick()%100) == 0)
    {

      if(STDownUartFrame.Over_time_count)
      {
        STDownUartFrame.Over_time_count --;  
        
        if (0 == STDownUartFrame.Over_time_count)
        {        
          STDownUartFrame.rx_step = 0;       
        }
      }
      if(STUpUartFrame.Over_time_count)
      {
        STUpUartFrame.Over_time_count --;  
          
        if (0 == STUpUartFrame.Over_time_count)
        {        
          STUpUartFrame.rx_step = 0;       
        }
      }
    }  
  }
}

static void IWDT_Config(void)
{
  RCC_OscInitTypeDef oscinit = {0};
  RCC_PeriphCLKInitTypeDef  periphclkinit = {0};
  
  /* Enable LSI Oscillator */
  oscinit.OscillatorType = RCC_OSCILLATORTYPE_LSI;
  oscinit.LSIState = RCC_LSI_ON;
  oscinit.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&oscinit)!= HAL_OK)
  {
    Error_Handler(); 
  }

  /* Configue LSI as RTC clock soucre */ 
  periphclkinit.PeriphClockSelection  = RCC_PERIPHCLK_RTC;
  periphclkinit.RTCClockSelection     = RCC_RTCCLKSOURCE_LSI;
  HAL_RCCEx_PeriphCLKConfig(&periphclkinit);
  
  __HAL_RCC_RTC_ENABLE(); 
  
  if(__HAL_RCC_GET_FLAG(RCC_FLAG_IWDGRST) != RESET)
  { 
    /* Clear reset flags */
    __HAL_RCC_CLEAR_RESET_FLAGS();
  }
  IwdgHandle.Instance = IWDG;

  IwdgHandle.Init.Prescaler = IWDG_PRESCALER_64;
  IwdgHandle.Init.Reload    =  0x00ff;//
  IwdgHandle.Init.Window    = IWDG_WINDOW_DISABLE;

  if(HAL_IWDG_Init(&IwdgHandle) != HAL_OK)
  {
    /* Initialization Error */
    Error_Handler();
  }
  
  /*##-4- Start the IWDG #####################################################*/ 
  
  if(HAL_IWDG_Start(&IwdgHandle) != HAL_OK)
  {
    Error_Handler();
  }
}
static void Error_Handler(void)
{
  while(1)
  {
  }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{
  while (1)
  {
  }
}
#endif

/**
  * @}
  */
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/ 
