#include "stm32f0xx.h"
#include "wireless_hal.h"






//static void delay_ms(unsigned int ms);


void NVIC_Init(NVIC_InitTypeDef* NVIC_InitStruct)
{
  uint32_t tmppriority = 0x00;

    
  if (NVIC_InitStruct->NVIC_IRQChannelCmd != DISABLE)
  {
    /* Compute the Corresponding IRQ Priority --------------------------------*/    
    tmppriority = NVIC->IP[NVIC_InitStruct->NVIC_IRQChannel >> 0x02];
    tmppriority &= (uint32_t)(~(((uint32_t)0xFF) << ((NVIC_InitStruct->NVIC_IRQChannel & 0x03) * 8)));
    tmppriority |= (uint32_t)((((uint32_t)NVIC_InitStruct->NVIC_IRQChannelPriority << 6) & 0xFF) << ((NVIC_InitStruct->NVIC_IRQChannel & 0x03) * 8));    
    
    NVIC->IP[NVIC_InitStruct->NVIC_IRQChannel >> 0x02] = tmppriority;
    
    /* Enable the Selected IRQ Channels --------------------------------------*/
    NVIC->ISER[0] = (uint32_t)0x01 << (NVIC_InitStruct->NVIC_IRQChannel & (uint8_t)0x1F);
  }
  else
  {
    /* Disable the Selected IRQ Channels -------------------------------------*/
    NVIC->ICER[0] = (uint32_t)0x01 << (NVIC_InitStruct->NVIC_IRQChannel & (uint8_t)0x1F);
  }
}





/***************** si4438��������� ***********************/
void Si4438Gpio_Init(void)
{
	RCC->AHBENR |= WIRELESS_PORT_CLOCK;			  //port clock enable
	
	SDN_GPIOX->MODER &= ~(3<<SDN_PIN*2);					//PA0 SDN
	SDN_GPIOX->MODER |= 1<<SDN_PIN*2;							//General purpose output mode
	SDN_GPIOX->OTYPER &= ~(1<<SDN_PIN);					//Output push-pull
	SDN_GPIOX->OSPEEDR &= ~(3<<SDN_PIN*2);				//Low speed	
	
	NIRQ_GPIOX->MODER &= ~(3<<NIRQ_PIN*2);					//NIRQ PA1 Input mode
	NIRQ_GPIOX->PUPDR &= ~(3<<NIRQ_PIN*2);					//
	NIRQ_GPIOX->PUPDR |= 1<<NIRQ_PIN*2;							//Pull-up
}


void NIRQ_IntEN(void)							// external interrupt
{				
	NVIC_InitTypeDef  NVIC_TEMP;						//Definition NVIC Init Structure Variate
  
	RCC->APB2ENR |= 1<<0;							//SYSCFG clock enable
	SYSCFG->EXTICR[NIRQ_PIN/4] &= ~(NIRQ_EXTIMAP<<4*(NIRQ_PIN%4));			//external interrupt mapping
  SYSCFG->EXTICR[NIRQ_PIN/4] |= NIRQ_EXTIMAP<<4*(NIRQ_PIN%4);			
	EXTI->IMR |= 1<<NIRQ_PIN;                //Interrupt request from Line 1 is not masked
  EXTI->FTSR |= 1<<NIRQ_PIN;               //Falling trigger enabled
	
	NVIC_TEMP.NVIC_IRQChannel = NIRQ_IMR_CHANNEL;		//Specifies the IRQ channel
	NVIC_TEMP.NVIC_IRQChannelPriority = NIRQ_IMR_PRIORITY;		//Specifies the priority
	NVIC_TEMP.NVIC_IRQChannelCmd = ENABLE;			//NVIC_IRQChannel will be enabled
	NVIC_Init(&NVIC_TEMP);
  
  EXTI->IMR |= 1<<NIRQ_EMR_NUMBER;
  EXTI->EMR |= 1<<NIRQ_EMR_NUMBER;                //Event request from Line 3 is not masked
  NVIC_TEMP.NVIC_IRQChannel = NIRQ_EMR_CHANNEL;		//Specifies the IRQ channel
	NVIC_TEMP.NVIC_IRQChannelPriority = NIRQ_EMR_PRIORITY;		//Specifies the priority
	NVIC_TEMP.NVIC_IRQChannelCmd = ENABLE;			//NVIC_IRQChannel will be enabled
	NVIC_Init(&NVIC_TEMP);
}



void SpiGpio_Init(void)
{
	NSEL_GPIOX->MODER &= ~(3<<NSEL_PIN*2);					//PA8 NSEL
	NSEL_GPIOX->MODER |= 1<<NSEL_PIN*2;							//General purpose output mode
	NSEL_GPIOX->OTYPER &= ~(1<<NSEL_PIN);					//Output push-pull
	NSEL_GPIOX->OSPEEDR &= ~(3<<NSEL_PIN*2);					
	NSEL_GPIOX->OSPEEDR |= 1<<NSEL_PIN*2;					//Medium speed
	NSEL_GPIOX->BSRR = 1<<NSEL_PIN;								//Sets the corresponding ODRx bit
  	
	GPIOA->AFR[0] &= 0x000fffff;       //Alternate function selection
	
  SCK_GPIOX->AFR[SCK_PIN/8] &= ~(15<<SCK_PIN*4);      
  SCK_GPIOX->AFR[SCK_PIN/8] |= SCK_AFSEL<<SCK_PIN*4;         //Alternate function selection
  SCK_GPIOX->MODER &= ~(3<<SCK_PIN*2);					//PA5 SCK
	SCK_GPIOX->MODER |= 2<<SCK_PIN*2;							//Alternate function mode
	SCK_GPIOX->OTYPER &= ~(1<<SCK_PIN);					//Output push-pull
	SCK_GPIOX->OSPEEDR &= ~(3<<SCK_PIN*2);					
	SCK_GPIOX->OSPEEDR |= 2<<SCK_PIN*2;					//High speed

  MOSI_GPIOX->AFR[MOSI_PIN/8] &= ~(15<<MOSI_PIN*4);      
  MOSI_GPIOX->AFR[MOSI_PIN/8] |= MOSI_AFSEL<<MOSI_PIN*4;         //Alternate function selection
  MOSI_GPIOX->MODER &= ~(3<<MOSI_PIN*2);					//PA7 MOSI
	MOSI_GPIOX->MODER |= 2<<MOSI_PIN*2;							//Alternate function mode
	MOSI_GPIOX->OTYPER &= ~(1<<MOSI_PIN);					//Output push-pull
	MOSI_GPIOX->OSPEEDR &= ~(3<<MOSI_PIN*2);					
	MOSI_GPIOX->OSPEEDR |= 2<<MOSI_PIN*2;					//High speed

  MISO_GPIOX->AFR[MISO_PIN/8] &= ~(15<<MISO_PIN*4);      
  MISO_GPIOX->AFR[MISO_PIN/8] |= MISO_AFSEL<<MISO_PIN*4;         //Alternate function selection
	MISO_GPIOX->MODER &= ~(3<<MISO_PIN*2);					//PA6 MISO
	MISO_GPIOX->MODER |= 2<<MISO_PIN*2;							//Alternate function mode
}




void SPI_Init(void)
{
  WIRELESS_SPI_CLKEN;                     //����SPIʱ��
 
  WIRELESS_SPI->CR1 &= ~(1<<7);            //��λ��ǰ
  WIRELESS_SPI->CR1 &= ~(7<<3);
  WIRELESS_SPI->CR1 |= 2<<3;               //1.5MHz(Ƶ�ʲ���̫��)
  
  
  WIRELESS_SPI->CR1 &= ~(1<<1);          //ʱ�Ӽ���Ĭ��Ϊ�͵�ƽ
  WIRELESS_SPI->CR1 &= ~(1<<0);          //��λΪ��һ�����ز���
  
//	WIRELESS_SPI->CR1 |= 1<<1;          //ʱ�Ӽ���Ĭ��Ϊ�ߵ�ƽ
//  WIRELESS_SPI->CR1 &= ~(1<<0);          //��λΪ�ڶ������ز���
	
	
	
	WIRELESS_SPI->CR1 |= 1<<2;          //����Ϊ���豸
//	WIRELESS_SPI->CR2 |= 1<<3;					//�����Զ�����NSS����
//	WIRELESS_SPI->CR2 |= 1<<2; 					//������ģʽNSS��ƽ���
	
  WIRELESS_SPI->CR1 |= 1<<9;          //������ģʽʹ����������
  WIRELESS_SPI->CR1 |= 1<<8;          //������ƽ�ĸߵ�����
  
  
  WIRELESS_SPI->CR2 |= 1<<12;        //��������Ϊ8λ
	
  WIRELESS_SPI->CR2 &= ~(15<<8);    
  WIRELESS_SPI->CR2 |= 7<<8;          //��������Ϊ8λ
  
  
  WIRELESS_SPI->CR1 |= 1<<6;          //SPIʹ��
  
  SPI_RWbyte(0xff);          ////��������(��Ҫ���ã�ά��MOSIΪ��)
}




uint8_t SPI_RWbyte(uint8_t sdata)
{ 
  volatile uint8_t *temp;
  
  //__disable_interrupt();
  while(!(WIRELESS_SPI->SR & 1<<1));  //�ȴ����ͻ���Ϊ��
  *(uint8_t *)&WIRELESS_SPI->DR = sdata;          //����һ���ֽ�
  // temp = (uint8_t *)&WIRELESS_SPI->DR;
  // *temp = sdata;          //����һ���ֽ�
  while(!(WIRELESS_SPI->SR & 1<<0));  //�ȴ����ջ�����
  temp = (uint8_t *)&WIRELESS_SPI->DR;
  //__enable_interrupt();
  return *temp;
}





//////////// ����ϵͳ����ʱ���������ļ�ʹ�� ////////////
void Si4438_Delay_ms(uint16_t nms)
{
  HAL_Delay(nms);
}
